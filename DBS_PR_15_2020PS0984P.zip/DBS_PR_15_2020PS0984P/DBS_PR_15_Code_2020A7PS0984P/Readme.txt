Hostel Management Portal 
(by Utsav Goel(2020A7PS0984P) and Hardik Jain(2020A7PS0102P) )

1) Open the html file using latest version of chrome.
2) First click on create table and then on make initial database.
3) Add the name of wing members and hostel they want and click on insert.
4) After adding all the names of students click on fetch record.
5) You can see the data with wing id alloted to students you entered.
6) Now click on allocate.
7) Then finally click on show allocation table, you can view the whole list of of allocation.

Strictly these steps must be followed in order to get the correct result.

IF YOU MAKE ANY ERROR WHILE ENTERING WING DATA , YOU CAN DELETE IT AFTER CLICKING DELETE RECORD BUTTON.
BEFORE REUSING THE SYSTEM, ALL PREVIOUSLY MADE TABLES MUST BE DELETED TO ENSURE SMOOTH WORKING OF THE SYSTEM.
CLICK ON YES/OK TO ALL DIALOG BOXES THAT APPEAR WHILE FOLLOWING THE STEPS. 

